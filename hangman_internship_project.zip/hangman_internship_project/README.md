# Python Hangman Game

A terminal-based Hangman game built with Python for a beginner programming project.

## Features

- Selects a random word from the supplied English word list.
- Gives the player up to six incorrect guesses.
- Displays ASCII gallows art that updates after each incorrect guess.
- Reveals correctly guessed letters.
- Tracks previously guessed letters.
- Prevents duplicate guesses from using an attempt.
- Validates input and displays clear victory or defeat messages.
- Includes fallback words if the word-list file is not present.

## Files

- `hangman.py` — the game.
- `google-10000-english-no-swears.txt` — word list used to choose a secret word.

## Requirements

Python 3. No extra packages are required; the game uses Python's standard library.

## How to run

1. Keep `hangman.py` and `google-10000-english-no-swears.txt` in the same folder.
2. Open that folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run:

   ```bash
   python hangman.py
   ```

   On some Windows installations, use `py hangman.py`.

## How to play

- Enter one letter per turn.
- Correct guesses reveal that letter in the hidden word.
- Incorrect guesses add one body part to the gallows.
- Repeating a guessed letter does not cost an attempt.
- Guess the full word before reaching six incorrect guesses to win.

## Concepts practiced

`random.choice()`, functions, lists, sets, loops, conditional statements, string handling, file reading, and input validation.
